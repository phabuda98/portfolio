# Network engineering portfolio labs

Three lab projects, with setup instructions, configurations and validation plans. These are authored learning projects, not claims of employment or successful live deployment.

1. campus/: Cisco VLAN segmentation, inter-VLAN routing, ACLs and OSPF in GNS3/EVE-NG.
2. vpn/: strongSwan IKEv2 tunnel on two isolated Ubuntu VMs.
3. automation/: Python/Netmiko read-only backups, checksum verification and a restore drill.

Read each README and record real results in RESULTS.md. Docker serves the portfolio site; Cisco images and the VM-based VPN lab are separate environments.
