# Lab evidence record

Status: configurations authored; live network tests not executed here.

For each test record:

| Test | Expected | Actual | Date / platform | Evidence file |
|---|---|---|---|---|
| Campus: users to servers | Allowed | Not run | | |
| Campus: guests to servers | Blocked | Not run | | |
| Campus: OSPF link failure / recovery | Route withdrawn / restored | Not run | | |
| VPN: cross-site ping with tunnel | Allowed / encrypted | Not run | | |
| VPN: cross-site ping without tunnel | Blocked | Not run | | |
| Backup: live SSH export | Saved / checksum valid | Not run | | |
| Backup: restore drill | Configuration verified | Not run | | |

Include sanitized show commands, packet captures and screenshots. Never publish credentials or raw production backups.

## Checks completed during authoring
Python syntax and shell syntax passed. Synthetic backup export, SHA-256 match, mode 0600, invalid device-name rejection, empty/error-response rejection and website link checks passed. These checks do not validate live network behavior.
