# Configuration backup workflow

Python 3.10+; Cisco IOS SSH devices with an account authorized for `show running-config`. This is read-only. The inventory contains example addresses: replace them with reachable SSH management addresses. The campus lab configs do not configure SSH; provision SSH and your own credentials separately.

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python backup.py --demo
python backup.py --inventory inventory.json
```

Demo mode requires no Netmiko installation and writes clearly marked synthetic configurations. Real mode prompts for username/password, or accepts NET_USERNAME / NET_PASSWORD / NET_SECRET through the environment. If the account starts in user mode, supply NET_SECRET for enable mode. Do not put credentials in inventory or Git.

Verify device host-key fingerprints through a trusted console, then add the verified keys to ~/.ssh/known_hosts. Strict checking rejects unknown or changed keys. Each device has timestamped files and SHA-256 sidecars, and one failed device does not prevent other backups. Exit status 1 indicates at least one failure.

Compare two files with `diff -u older.cfg newer.cfg`; verify a backup with `sha256sum -c timestamp.sha256` from its directory. SHA-256 detects accidental changes; it is not an authenticity signature.

## Schedule
Run under a dedicated account, with securely supplied credentials and verified known_hosts. Example cron entry (replace absolute paths):
```text
0 2 * * * /srv/network-backups/.venv/bin/python /srv/network-backups/backup.py --inventory /srv/network-backups/inventory.json --output /srv/network-backups/backups >> /srv/network-backups/backup.log 2>&1
```
Prompting cannot work in cron. Configure credentials through your scheduler/secret manager. Secure raw backups, which may contain secrets. Keep them out of the public website and Git; publish only redacted samples. Add your own retention policy.

## Restore drill
Use a disposable matching IOS lab device. Compare current and saved configs, inspect interface mapping and credentials, then transfer the selected backup to a private lab SCP server. With console access, use the image-supported `configure replace` procedure or manually apply reviewed differences. Verify routes, VLANs and access policy before saving. This tool never performs a restore automatically.

Expected checks: demo writes files; correct credentials save real configurations; unknown host key and wrong password fail; SHA-256 matches; changed config produces a meaningful diff. Record actual results in ../RESULTS.md.

Reference: https://ktbyers.github.io/netmiko/docs/netmiko/
