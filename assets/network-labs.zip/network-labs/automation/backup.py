"""Read-only Cisco configuration backups. Never pushes configuration."""
import argparse, datetime, getpass, hashlib, json, os, re, sys
from pathlib import Path

def save_backup(folder, name, text):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        raise ValueError("Device name must contain only letters, digits, _ or -")
    if not text.strip() or text.lstrip().startswith(("%", "Invalid", "Error")):
        raise ValueError("Empty or rejected device response")
    folder = Path(folder) / name
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    path = folder / (stamp + ".cfg")
    with path.open("x") as file:
        os.chmod(path, 0o600)
        file.write(text.rstrip() + "\n")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    path.with_suffix(".sha256").write_text(digest + "  " + path.name + "\n")
    return path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inventory", default="inventory.json")
    parser.add_argument("--output", default="backups")
    parser.add_argument("--demo", action="store_true", help="Save synthetic data without connecting")
    args = parser.parse_args()
    devices = json.loads(Path(args.inventory).read_text())
    if not args.demo:
        from netmiko import ConnectHandler
        username = os.environ.get("NET_USERNAME") or input("SSH username: ")
        password = os.environ.get("NET_PASSWORD") or getpass.getpass("SSH password: ")
        secret = os.environ.get("NET_SECRET", "")
    failed = False
    for device in devices:
        name = device["name"]
        try:
            if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
                raise ValueError("Invalid device name")
            if args.demo:
                config = "! SYNTHETIC DEMO, not a live backup\nhostname " + name + "\n"
            else:
                with ConnectHandler(host=device["host"], port=device.get("port",22),
                        device_type="cisco_ios", username=username, password=password,
                        secret=secret, ssh_strict=True, system_host_keys=True,
                        conn_timeout=10, auth_timeout=15) as connection:
                    if secret:
                        connection.enable()
                    config = connection.send_command("show running-config", read_timeout=60)
            path = save_backup(args.output, name, config)
            print(name + ": saved " + str(path))
        except Exception as error:
            # Avoid logging raw exception messages that may contain session data.
            print(name + ": failed (" + type(error).__name__ + ")", file=sys.stderr)
            failed = True
    return 1 if failed else 0
if __name__ == "__main__":
    sys.exit(main())
