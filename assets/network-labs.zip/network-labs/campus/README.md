# Segmented campus network

## Goal and topology
Build in GNS3 or EVE-NG with licensed Cisco IOSvL2 multilayer-capable images and an IOSv router. Some images require `switchport trunk encapsulation dot1q` before trunk mode. The configurations use Gi0/x; map to your image. There is one uplink, so this lab tests failure detection, not high availability.

```mermaid
flowchart TD
 EDGE["EDGE / OSPF"] --- CORE["CORE / VLAN gateways"]
 CORE --- ACCESS["ACCESS / 802.1Q trunk"]
 ACCESS --- USER["Users / VLAN 10"]
 ACCESS --- SERVER["Servers / VLAN 20"]
 ACCESS --- GUEST["Guests / VLAN 30"]
```

| Segment | Host | Gateway |
|---|---|---|
| Users / VLAN 10 | 10.10.10.10/24 | 10.10.10.1 |
| Servers / VLAN 20 | 10.10.20.10/24 | 10.10.20.1 |
| Guests / VLAN 30 | 10.10.30.10/24 | 10.10.30.1 |
| CORE to EDGE | 10.10.254.1/30 and .2/30 | Direct link |
| Simulated external endpoint | EDGE loopback 198.51.100.1/32 | OSPF |

Connect ACCESS Gi0/0 to CORE Gi0/0, CORE Gi0/1 to EDGE Gi0/0. Attach the three hosts to ACCESS Gi0/1, Gi0/2, Gi0/3 respectively. Assign host IPs and default gateways manually. Apply the matching configs via console and save using `copy running-config startup-config`. VLAN SVIs require an active member port/trunk.

## Policy
Users may reach servers. Guests may ping their gateway and access the simulated external endpoint, but cannot reach RFC1918 destinations. This is a stateless IPv4 ACL lab, not a complete production security policy. IPv6 is outside scope. No internet, NAT, DHCP, or DNS is configured.

## Validation (expected results, not recorded results)
- `show vlan brief`: access ports assigned to VLANs 10, 20, 30.
- `show interfaces trunk`: all three VLANs allowed and forwarding.
- `show ip ospf neighbor`: CORE and EDGE reach FULL.
- `show ip route ospf`: CORE learns 198.51.100.1; EDGE learns three /24 routes.
- User ping 10.10.20.10: allowed; guest ping 10.10.20.10: blocked.
- Guest ping 10.10.30.1 and 198.51.100.1: allowed.
- `show access-lists GUEST-IN`: deny counter rises during blocked guest tests.
- Shut CORE Gi0/1: external reachability fails, inter-VLAN routing remains. Bring it up: neighbor and route recover. Capture timestamps rather than inventing convergence figures.

Save command output and screenshots in `evidence/`; use ../RESULTS.md. Troubleshoot host gateway, active VLANs, trunk lists, ACL direction, and OSPF area/subnet in that order.

Reference: https://www.cisco.com/c/en/us/td/docs/routers/ios-xe/ip-routing/b-ip-routing/m_iri-default-passive-interface.html
