#!/bin/sh
set -eu
# Run on a disposable lab VM via console. Dedicated lab interfaces only.
WAN=${WAN:-ens3}
LAN=${LAN:-ens4}
iptables -P FORWARD DROP
iptables -F FORWARD
iptables -A FORWARD -i "$LAN" -o "$WAN" -s 10.1.0.0/24 -d 10.2.0.0/24 -m policy --dir out --pol ipsec --proto esp --mode tunnel -j ACCEPT
iptables -A FORWARD -i "$WAN" -o "$LAN" -s 10.2.0.0/24 -d 10.1.0.0/24 -m policy --dir in --pol ipsec --proto esp --mode tunnel -j ACCEPT
